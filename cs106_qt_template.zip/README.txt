How to Add Stanford C++ Library

Insted of copying the entire StanfordCPPLib folder to every project, just paste the shortcut to that folder
in lib folder of the project file.
